package com.stephenbrown.books.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.stephenbrown.books.models.Book;
import com.stephenbrown.books.services.BookService;

@Controller
public class BookController {
	
	@Autowired
	BookService bookService;

	@RequestMapping("/books/2")
	public String index() {
		return "index.jsp";
	}

	@RequestMapping("/books/{bookId}")
	public String show(@PathVariable("bookId") Long bookId, Model model) {
		System.out.println(bookId);
		Book book = bookService.findBook(bookId); 
		
		model.addAttribute("book",book);
		
		return "show.jsp";
	} 
}


	