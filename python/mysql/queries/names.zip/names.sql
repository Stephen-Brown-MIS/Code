-- Select all items in the table
Select * from names;

-- Insert my name into the table
insert into names (name) value 
("Jim"),
("Judith"),
("Jaime"),
("Suzanne");
--
Delete from names where id > 7;