public class GorrillaTest {
    public static void main(String[] args) {
    Gorilla Kong = new Gorilla(100);
    Kong.throwSomething();
    Kong.throwSomething();
    Kong.throwSomething();
    Kong.eatBanas();
    Kong.eatBanas();
    Kong.climb();
    Kong.climb();
}

}
