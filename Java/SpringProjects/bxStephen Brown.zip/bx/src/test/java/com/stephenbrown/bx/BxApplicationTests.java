package com.stephenbrown.bx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BxApplicationTests {

	@Test
	void contextLoads() {
	}

}
