var childHeight = 48

function displayIfChildisAbleToRideTheRollerCoaster ()
{
If childHeight > 52
    {
        console.log("Get on that ride kiddo!")
    }
else
    {
        console.log("Sorry kiddo. Maybe next year.")
    }
}

displayIfChildisAbleToRideTheRollerCoaster()