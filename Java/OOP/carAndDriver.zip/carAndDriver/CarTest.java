public class CarTest {
    public static void main(String[] args) {
       Driver Enzo = new Driver();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.boostCar();
       Enzo.refuelCar();
       Enzo.refuelCar();
       Enzo.refuelCar();
       Enzo.boostCar();
       Enzo.boostCar();
       Enzo.boostCar();
       Enzo.boostCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       Enzo.driveCar();
       
    }
    
}
