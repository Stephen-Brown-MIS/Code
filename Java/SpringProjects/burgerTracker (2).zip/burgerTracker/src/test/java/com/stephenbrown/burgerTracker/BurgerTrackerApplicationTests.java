package com.stephenbrown.burgerTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BurgerTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
