/**
 * 
 */
/**
 * @author steph
 *
 */
module careSoftInterfaces {
}