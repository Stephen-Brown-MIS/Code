public class BatTest {
    public static void main(String[] args) {
    Bat Laszlo = new Bat(300);
    Laszlo.attackTown();
    Laszlo.attackTown();
    Laszlo.attackTown();
    Laszlo.eatHumans();
    Laszlo.eatHumans();
    Laszlo.fly();
    Laszlo.fly();
}

}
