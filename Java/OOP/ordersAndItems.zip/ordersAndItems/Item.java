public class Item {
    public String name;
    public double price;
}
