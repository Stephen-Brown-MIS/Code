package com.stephenbrown.bx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BxApplication {

	public static void main(String[] args) {
		SpringApplication.run(BxApplication.class, args);
	}

}
